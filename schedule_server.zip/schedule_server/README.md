# 📅 Schedule Server (Dart + Alfred + Hive)

대학생 시간표 / 스케줄링 앱을 위한 **백엔드 서버**입니다.  
Hive 로컬 DB를 기반으로 그룹별로 스케줄을 저장하고, Alfred 프레임워크로 REST API를 제공합니다.

---

## 📦 기술 스택

- **Dart**
- **Alfred** – 경량 REST API 프레임워크
- **Hive** – Key-Value 기반 로컬 DB
- **Postman** – 테스트용 도구

---

## 📂 프로젝트 구조

```
schedule_server/
├── bin/
│   └── main.dart                 # Alfred 서버 진입점
├── lib/
│   ├── models/
│   │   ├── group.dart           # Group 모델
│   │   └── schedule.dart        # Schedule 모델
│   ├── routes/
│   │   ├── group_routes.dart    # 그룹 관련 API
│   │   ├── schedule_routes.dart # 스케줄 관련 API
│   │   └── import_google_events_route.dart # 구글 캘린더 일정 연동 API
│   └── utils/
│       └── response.dart        # 공통 응답 포맷
├── hive_data/                   # Hive 저장소 경로
```

---

## ✅ 구현된 기능

### 📁 그룹(Group)
- `GET /groups` : 모든 그룹 목록 조회
- `GET /groups/:id` : 특정 그룹 조회
- `POST /groups` : 새 그룹 생성 (자동 groupId 부여)
- `DELETE /groups/:id` : 그룹 삭제

### 🗓️ 일정(Schedule)
- `GET /schedule/` : 전체 일정 목록 조회 (startTime 기준 정렬)
- `GET /schedule/:id` : 개별 일정 조회
- `POST /schedule/` : 새 일정 생성 (자동 scheduleId 부여)
- `PUT /schedule/:id` : 일정 수정
- `DELETE /schedule/:id` : 일정 삭제
- `GET /schedule/group/:groupId` : 특정 그룹의 일정 목록 조회
- `GET /import-google-events?access_token=...` : Google Calendar 일정 단방향 가져오기

---

## 🧱 데이터 모델

### 🟦 Group

| 필드     | 타입     | 설명                     |
|----------|----------|--------------------------|
| groupId  | `int`    | 그룹 고유 ID             |
| color    | `String` | 그룹 색상 (`#RRGGBB`)    |
| title    | `String` | 그룹 이름                |
| priority | `int`    | 정렬용 우선순위          |

```dart
Map<String, dynamic> toJson() => {
  'groupId': groupId,
  'color': color,
  'title': title,
  'priority': priority,
};
```

### 🟧 Schedule

| 필드         | 타입         | 설명                     |
|--------------|--------------|--------------------------|
| scheduleId   | `int`        | 스케줄 고유 ID           |
| title        | `String`     | 제목                     |
| content      | `String`     | 상세 내용                |
| location     | `String`     | 장소                     |
| locationUrl  | `String`     | 지도 URL (선택 입력)     |
| startTime    | `DateTime`   | 시작 시간                |
| endTime      | `DateTime`   | 종료 시간                |
| alarm        | `bool`       | 알람 설정 여부           |
| groupId      | `int`        | 소속 그룹의 ID           |

```dart
Map<String, dynamic> toJson() => {
  'scheduleId': scheduleId,
  'title': title,
  'content': content,
  'location': location,
  'locationUrl': locationUrl,
  'startTime': startTime.toIso8601String(),
  'endTime': endTime.toIso8601String(),
  'alarm': alarm,
  'groupId': groupId,
};
```

---

## 📤 예시 요청

### 그룹 생성 요청
```json
{
  "color": "#FFFFFF",
  "title": "자료 구조",
  "priority": 0
}
```

### 스케줄 생성 요청
```json
{
  "title": "챕터 3 복습",
  "content": "연결 리스트 구현 복습",
  "location": "도서관",
  "locationUrl": "https://www.google.com/maps/search/?api=1&query=도서관",
  "startTime": "2025-07-24T10:00:00",
  "endTime": "2025-07-24T12:00:00",
  "alarm": true,
  "groupId": 0
}
```

---

## ⚙️ 실행 방법

```bash
1. 의존성 설치
$ dart pub get

2. Hive 어댑터 코드 생성
$ dart run build_runner build --delete-conflicting-outputs

3. 서버 실행
$ dart run bin/main.dart
```

- 실행 후 기본 주소: `http://localhost:8080`
- Hive 데이터는 `hive_data/` 폴더에 저장됨

---

## 🧪 테스트 방법
- Postman 등으로 API 요청 테스트
- 요청 바디는 반드시 JSON(raw) 형식으로 전송해야 함
- 주요 엔드포인트:
  - `POST /groups`
  - `POST /schedule/`
  - `GET /schedule/group/:groupId`

---

## 🎨 클라이언트 색상 처리 예시 (Flutter)
```dart
Color getScheduleColor(Schedule s) {
  final group = groups.firstWhere((g) => g.groupId == s.groupId);
  return Color(int.parse(group.color.replaceAll('#', '0xFF')));
}
```

---

## ✅ 안정성 보완 사항

- 모든 API 요청에 try-catch 적용
- int.parse, DateTime.parse, Hive 접근 시 오류 처리
- 요청 필드 유효성 검사 (groupId, title, startTime, endTime 등)
- 404 / 400 / 500 에러 코드 분리 처리

---

## 📍 지도 연동 기능 (1단계: 클라이언트 URL 수신 기반)

- 사용자가 Flutter 앱에서 지도에서 검색 후 URL을 복사하거나 선택
- 서버에 `locationUrl` 필드로 함께 전송
- 서버는 해당 URL을 그대로 저장하여 클라이언트에 응답 시 포함
- 예:

```json
{
  "location": "서울대학교",
  "locationUrl": "https://www.google.com/maps/search/?api=1&query=서울대학교"
}
```

- 향후 Flutter 앱에서 지도 선택 UI 구현 시 확장 예정

---

## 🔄 Google Calendar 연동 (단방향)

- 클라이언트(Flutter)에서 로그인하여 access token을 받아 서버에 전송
- 서버에서는 해당 토큰으로 사용자의 캘린더에서 일정만 읽어옴
- 방향: Google Calendar → Schedule App (쓰기 X)

### ✅ 서버 구현 완료 사항:
- `/import-google-events` API 구축 완료
- access token 전달 → Google Calendar API 호출
- 일정 필터링: 오늘 기준 2개월 이후까지만 가져오기 적용됨
- 중복 이벤트 자동 건너뜀 (title, startTime, endTime 기준)
- 기본 그룹(`groupId = 0`)에 자동 저장됨

### ✅ 클라이언트 요구 사항:
- `google_sign_in` 패키지로 Google 로그인 구현
- accessToken 추출 및 서버 전송 (GET 요청 파라미터)

### ✅ Google OAuth 클라이언트 등록 상태
- 유형: Android
- 패키지 이름: `com.cheolho.scheduleapp`
- SHA-1 인증서 지문: debug.keystore로부터 추출하여 등록 완료
- Google Cloud Console 등록 확인됨 (2025-08-05 생성)

---

## 📌 향후 개발 계획

- [x] 📦 응답 포맷 통일 (success, data, message 구조)
- [N] 🔥 전역 에러 핸들러 (app.errorHandler) 적용<버젼 오류 때문에 안하기로>
- [ ] 🧪 입력값 유효성 검사 강화 (빈 문자열, 날짜 범위 등)
- [x] 📁 코드 분리 완료 (routes/, models/, utils 구조 적용)
- [ ] 📋 Swagger / Postman 문서 자동화
- [ ] 📜 로깅 시스템 도입
- [ ] 🧪 테스트 코드 작성 (unit & integration)
- [ ] 🌐 CORS 허용 설정
- [ ] 🔄 반복 스케줄 기능
- [ ] 🔍 스케줄 검색 기능
- [ ] ⭐ 즐겨찾기, 중요도 표시 기능
- [ ] 📅 Google Calendar → 단방향 일정 가져오기 (OAuth2, Google API 연동)
- [ ] 🗺 지도 좌표 선택 방식 연동 (Flutter에서 좌표 선택 후 locationUrl 전송)

---

## ✍️ 작성자

- 최철호  
- Dart + Flutter 기반 시간표/스케줄링 앱 개발자
