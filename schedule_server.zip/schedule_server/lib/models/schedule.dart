import 'package:hive/hive.dart';

part 'schedule.g.dart';

@HiveType(typeId: 1)
class Schedule extends HiveObject {
  @HiveField(0)
  final int scheduleId;

  @HiveField(1)
  final String title;

  @HiveField(2)
  final String content;

  @HiveField(3)
  final String location;

  @HiveField(4)
  final String locationUrl;

  @HiveField(5)
  final DateTime startTime;

  @HiveField(6)
  final DateTime endTime;

  @HiveField(7)
  final bool alarm;

  @HiveField(8)
  final int groupId;

  Schedule({
    required this.scheduleId,
    required this.title,
    required this.content,
    required this.location,
    required this.locationUrl,
    required this.startTime,
    required this.endTime,
    required this.alarm,
    required this.groupId,
  });

  Map<String, dynamic> toJson() {
    final json = {
      'scheduleId': scheduleId,
      'title': title,
      'content': content,
      'location': location,
      'locationUrl': locationUrl,
      'startTime': startTime.toIso8601String(),
      'endTime': endTime.toIso8601String(),
      'alarm': alarm,
      'groupId': groupId,
    };
    if (content.trim().isNotEmpty) {
      json['content'] = content;
    }
    if (location.trim().isNotEmpty) {
      json['location'] = location;
    }
    if (locationUrl.trim().isNotEmpty) {
      json['locationUrl'] = locationUrl;
    }
    return json;
  }
}
