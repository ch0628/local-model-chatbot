import 'dart:convert';
import 'package:alfred/alfred.dart';
import 'package:http/http.dart' as http;
import 'package:hive/hive.dart';

import '../models/schedule.dart';
import '../models/group.dart';
import '../utils/response.dart';

void registerGoogleCalendarRoute(
  Alfred app,
  Box<Schedule> scheduleBox,
  Box<Group> groupBox,
) {
  app.get('/import-google-events', (req, res) async {
    final accessToken = req.uri.queryParameters['access_token'];
    if (accessToken == null) {
      res.statusCode = 400;
      return errorResponse('access_token 쿼리 파라미터가 필요합니다.');
    }

    try {
      final now = DateTime.now();
      final twoMonthsAgo = DateTime(now.year, now.month - 2, now.day);
      final timeMinIso = twoMonthsAgo.toUtc().toIso8601String();

      final uri = Uri.parse(
        'https://www.googleapis.com/calendar/v3/calendars/primary/events'
        '?maxResults=30'
        '&orderBy=startTime'
        '&singleEvents=true'
        '&timeMin=$timeMinIso',
      );

      final response = await http.get(
        uri,
        headers: {'Authorization': 'Bearer $accessToken'},
      );

      if (response.statusCode != 200) {
        res.statusCode = 401;
        return errorResponse('Google Calendar 인증 실패', data: response.body);
      }

      final data = jsonDecode(response.body);
      final List items = data['items'];
      int addedCount = 0;

      for (final item in items) {
        final summary = item['summary'] ?? '제목 없음';
        final content = item['description'] ?? '';
        final location = item['location'] ?? '';
        final start = item['start']?['dateTime'];
        final end = item['end']?['dateTime'];

        if (start == null || end == null) continue;

        final startTime = DateTime.parse(start);
        final endTime = DateTime.parse(end);

        // 중복 방지 (같은 title, 시간대)
        final exists = scheduleBox.values.any(
          (s) =>
              s.title == summary &&
              s.startTime == startTime &&
              s.endTime == endTime,
        );
        if (exists) continue;

        final newId = scheduleBox.isEmpty
            ? 0
            : (scheduleBox.keys.cast<int>().reduce((a, b) => a > b ? a : b) +
                  1);

        final newSchedule = Schedule(
          scheduleId: newId,
          title: summary,
          content: content,
          location: location,
          locationUrl: '',
          startTime: startTime,
          endTime: endTime,
          alarm: false,
          groupId: 0, // 기본 그룹 (예: 내 일정)
        );

        await scheduleBox.put(newSchedule.scheduleId, newSchedule);
        addedCount++;
      }

      return successResponse({
        'imported': addedCount,
      }, message: 'Google 일정 가져오기 완료');
    } catch (e) {
      res.statusCode = 500;
      return errorResponse('Google 일정 가져오기 중 오류', data: e.toString());
    }
  });
}
