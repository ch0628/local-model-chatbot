import 'package:alfred/alfred.dart';
import 'package:hive/hive.dart';
import '../models/group.dart';
import '../utils/response.dart';

void registerGroupRoutes(Alfred app, Box<Group> groupBox) {
  // 서버 시작 시 기본 그룹이 없으면 추가
  if (!groupBox.containsKey(0)) {
    groupBox.put(
      0,
      Group(groupId: 0, color: '#BDBDBD', title: '기본 일정', priority: -1),
    );
  }

  // group 목록 불러오기
  app.get('/groups', (req, res) async {
    try {
      final result = groupBox.values.map((g) => g.toJson()).toList()
        ..sort((a, b) => a['priority'].compareTo(b['priority']));
      return successResponse(result, message: '그룹 목록 조회 성공');
    } catch (e) {
      res.statusCode = 500;
      return errorResponse('서버 에러 발생[group 목록 불러오기]', data: e.toString());
    }
  });

  // group 하나만 보기
  app.get('/groups/:id', (req, res) async {
    try {
      final groupId = int.parse(req.params['id']!);
      final group = groupBox.get(groupId);
      if (group == null) {
        res.statusCode = 404;
        return errorResponse('Group not found[group 하나만 보기]');
      }
      return successResponse(group.toJson(), message: 'Group fetched');
    } catch (e) {
      res.statusCode = 400;
      return errorResponse('서버 에러 발생[group 하나만 보기]', data: e.toString());
    }
  });

  // group 생성 (자동 ID 부여, 0번 제외)
  app.post('/groups', (req, res) async {
    try {
      final groupData = await req.bodyAsJsonMap;

      if (groupData['title'] == null ||
          groupData['title'].toString().trim().isEmpty) {
        res.statusCode = 400;
        return errorResponse("제목은 반드시 입력해야 합니다.");
      }

      // groupId = 0 제외하고 최대값 + 1
      final newId =
          groupBox.keys
              .cast<int>()
              .where((id) => id != 0)
              .fold(0, (prev, id) => id > prev ? id : prev) +
          1;
      final newGroup = Group(
        groupId: newId,
        color: groupData['color'] ?? '#FFFFFF',
        title: groupData['title'],
        priority: groupData['priority'] ?? 0,
      );
      await groupBox.put(newGroup.groupId, newGroup);
      return successResponse(
        newGroup.toJson(),
        message: 'Group added[group 생성]',
      );
    } catch (e) {
      res.statusCode = 500;
      return errorResponse(
        'Internal server error[group 생성]',
        data: e.toString(),
      );
    }
  });

  // group 삭제
  app.delete('/groups/:id', (req, res) async {
    try {
      final groupId = int.parse(req.params['id']!);
      if (groupId == 0) {
        res.statusCode = 400;
        return errorResponse('기본 그룹은 삭제할 수 없습니다');
      }
      await groupBox.delete(groupId);
      return successResponse(null, message: 'Group deleted');
    } catch (e) {
      res.statusCode = 400;
      return errorResponse('Invalid group ID[group 삭제]', data: e.toString());
    }
  });
}
