import 'package:alfred/alfred.dart';
import 'package:hive/hive.dart';
import '../models/schedule.dart';
import '../models/group.dart';
import '../utils/response.dart';

void registerScheduleRoutes(
  Alfred app,
  Box<Schedule> scheduleBox,
  Box<Group> groupBox,
) {
  // schedule 목록 불러오기
  app.get('schedule/', (req, res) async {
    try {
      final result = scheduleBox.values.map((s) => s.toJson()).toList()
        ..sort(
          (a, b) => DateTime.parse(
            a['startTime'],
          ).compareTo(DateTime.parse(b['startTime'])),
        );
      return successResponse(result, message: 'fetch schedule list completed');
    } catch (e) {
      res.statusCode = 500;
      return errorResponse(
        'Faled to fetch schedules[schedule 목록 불러오기]',
        data: e.toString(),
      );
    }
  });

  // schedule 하나만 보기
  app.get('/schedule/:id', (req, res) async {
    try {
      final scheduleId = int.parse(req.params['id']!);
      final schedule = scheduleBox.get(scheduleId);

      if (schedule == null) {
        res.statusCode = 404;
        return errorResponse("Schedule not found[schedule 하나만 보기]");
      }

      return successResponse(schedule.toJson(), message: '스케줄 조회 성공');
    } catch (e) {
      res.statusCode = 400;
      return errorResponse(
        'Invalid schedule Id[schedule 하나만 보기]',
        data: e.toString(),
      );
    }
  });

  // schedule 생성
  app.post('schedule/', (req, res) async {
    try {
      final scheduleData = await req.bodyAsJsonMap;
      final fixedTitle =
          (scheduleData['title'] == null ||
              scheduleData['title'].toString().trim().isEmpty)
          ? '내 일정'
          : scheduleData['title'];

      final fixedContent =
          (scheduleData['content'] == null ||
              scheduleData['content'].toString().trim().isEmpty)
          ? ''
          : scheduleData['content'];

      final fixedLocation =
          (scheduleData['location'] == null ||
              scheduleData['location'].toString().trim().isEmpty)
          ? ''
          : scheduleData['location'];

      final fixedLocationUrl =
          (scheduleData['locationUrl'] == null ||
              scheduleData['locationUrl'].toString().trim().isEmpty)
          ? ''
          : scheduleData['locationUrl'];

      final newId = scheduleBox.isEmpty
          ? 0
          : (scheduleBox.keys.cast<int>().reduce((a, b) => a > b ? a : b) + 1);

      final newSchedule = Schedule(
        scheduleId: newId,
        title: fixedTitle,
        content: fixedContent,
        location: fixedLocation,
        locationUrl: fixedLocationUrl,
        startTime: DateTime.parse(scheduleData['startTime']),
        endTime: DateTime.parse(scheduleData['endTime']),
        alarm: scheduleData['alarm'],
        groupId: scheduleData['groupId'],
      );

      final group = groupBox.get(newSchedule.groupId);
      if (group == null) {
        res.statusCode = 404;
        return errorResponse('Group not found[schedule 생성]');
      }

      if (DateTime.parse(
        scheduleData['startTime'],
      ).isAfter(DateTime.parse(scheduleData['endTime']))) {
        res.statusCode = 400;
        return errorResponse('startTime은 endTime보다 앞서야 합니다');
      }

      await scheduleBox.put(newSchedule.scheduleId, newSchedule);
      return successResponse(newSchedule.toJson(), message: 'schedule added');
    } catch (e) {
      res.statusCode = 500;
      return errorResponse('Failed to create schedule', data: e.toString());
    }
  });

  // schedule 수정
  app.put('/schedule/:id', (req, res) async {
    try {
      final id = int.parse(req.params['id']!);
      final data = await req.bodyAsJsonMap;

      final updated = Schedule(
        scheduleId: id,
        title: data['title'],
        content: data['content'],
        location: data['location'],
        locationUrl: data['locationUrl'],
        startTime: DateTime.parse(data['startTime']),
        endTime: DateTime.parse(data['endTime']),
        alarm: data['alarm'],
        groupId: data['groupId'],
      );

      final group = groupBox.get(updated.groupId);
      if (group == null) {
        res.statusCode = 404;
        return errorResponse('Group not found[schedule 수정]');
      }

      if (DateTime.parse(
        data['startTime'],
      ).isAfter(DateTime.parse(data['endTime']))) {
        res.statusCode = 400;
        return errorResponse('startTime은 endTime보다 앞서야 합니다');
      }

      await scheduleBox.put(id, updated);
      return successResponse(updated.toJson(), message: 'Schedule updated');
    } catch (e) {
      res.statusCode = 500;
      return errorResponse(
        'Failed to update schedule[schedule 수정]',
        data: e.toString(),
      );
    }
  });

  // schedule 삭제
  app.delete('/schedule/:id', (req, res) async {
    try {
      final scheduleId = int.parse(req.params['id']!);
      await scheduleBox.delete(scheduleId);
      return successResponse(null, message: 'Schedule deleted');
    } catch (e) {
      res.statusCode = 400;
      return errorResponse('Invalid schedule ID', data: e.toString());
    }
  });

  // group 안의 schedule 조회
  app.get('/schedule/group/:groupId', (req, res) async {
    try {
      final newGroupId = int.parse(req.params['groupId']!);
      final filtered = scheduleBox.values
          .where((s) => s.groupId == newGroupId)
          .map((s) => s.toJson())
          .toList();
      return successResponse(filtered, message: '해당 그룹의 스케줄 목록');
    } catch (e) {
      res.statusCode = 400;
      return errorResponse(
        'Invalid group ID[group 안의 schedule 조회]',
        data: e.toString(),
      );
    }
  });
}
