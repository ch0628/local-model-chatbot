Map<String, dynamic> successResponse(
  dynamic data, {
  String message = 'Success',
}) {
  return {'success': true, 'data': data, 'message': message};
}

Map<String, dynamic> errorResponse(String message, {dynamic data}) {
  return {'success': false, 'data': data, 'message': message};
}
